angular.module("CONTROLLER_NAME", [])
    .controller("name", ["$scope", function ($scope) {

    }]);