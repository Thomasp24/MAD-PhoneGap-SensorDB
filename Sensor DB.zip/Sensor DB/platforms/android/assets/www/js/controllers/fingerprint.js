/**
 * Created by Gert on 15-11-2016.
 */
angular.module("CONTROLLER_NAME", [])
    .controller("name", ["$scope", function ($scope) {

    }]);